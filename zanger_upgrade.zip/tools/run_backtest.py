# tools/run_backtest.py
import json, glob, os
from src.backtest import backtest_scan_results
import pandas as pd

SCAN_DIR = "scan_results"
OUT_DIR = "backtest_results"
os.makedirs(OUT_DIR, exist_ok=True)

def latest_scan_file():
    files = sorted(glob.glob(f"{SCAN_DIR}/scan_*.json"))
    if not files:
        raise FileNotFoundError("No scan JSON files found in scan_results/")
    return files[-1]

def run():
    scan_file = latest_scan_file()
    with open(scan_file, "r") as f:
        data = json.load(f)
    df = backtest_scan_results(data)
    out_csv = f"{OUT_DIR}/backtest_summary_{os.path.basename(scan_file).replace('.json','.csv')}"
    df.to_csv(out_csv, index=False)
    print("Backtest saved to", out_csv)

if __name__ == "__main__":
    run()
