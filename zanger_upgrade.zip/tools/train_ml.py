# tools/train_ml.py
import glob
from src.ml_pipeline import train_model

def latest_backtest_files():
    return sorted(glob.glob("backtest_results/*.csv"))

def main():
    csvs = latest_backtest_files()
    if not csvs:
        print("No backtest CSV files.")
        return
    train_model(csvs)

if __name__ == "__main__":
    main()
