# src/backtest.py
import pandas as pd
import numpy as np
from typing import Dict, Any, List

def evaluate_post_breakout(df: pd.DataFrame, breakout_idx: int, horizons: List[int] = [1,3,5,10,20]) -> Dict[int, float]:
    results = {}
    n = len(df)
    for h in horizons:
        target_idx = breakout_idx + h
        if target_idx >= n:
            results[h] = np.nan
            continue
        entry = df['Close'].iloc[breakout_idx]
        exitp = df['Close'].iloc[target_idx]
        results[h] = 100.0 * (exitp - entry) / entry
    return results

def backtest_scan_results(scan_json: Dict[str, Any], look_horizons=[1,3,5,10,20]):
    import yfinance as yf
    rows = []
    import pandas as pd
    for ticker, info in scan_json.items():
        if not isinstance(info, dict) or 'breakout' not in info:
            rows.append({"ticker": ticker, "status": "no_pattern"})
            continue
        bo = info['breakout']
        bo_date = bo.get('date')
        if bo_date is None:
            rows.append({"ticker": ticker, "status": "no_breakout_date"})
            continue
        start = pd.to_datetime(bo_date) - pd.Timedelta(days=5)
        end = pd.to_datetime(bo_date) + pd.Timedelta(days=60)
        try:
            df = yf.download(ticker, start=start.strftime("%Y-%m-%d"), end=end.strftime("%Y-%m-%d"), progress=False)
            if df.empty:
                rows.append({"ticker": ticker, "status": "no_data"})
                continue
            date_idx = df.index.get_loc(pd.to_datetime(bo_date))
            perf = evaluate_post_breakout(df.reset_index(drop=False), date_idx, horizons=look_horizons)
            row = {"ticker": ticker, "status": "ok"}
            for h, r in perf.items():
                row[f"r_{h}d"] = float(r) if not np.isnan(r) else None
            rows.append(row)
        except Exception as e:
            rows.append({"ticker": ticker, "status": "error", "error": str(e)})
    return pd.DataFrame(rows)
